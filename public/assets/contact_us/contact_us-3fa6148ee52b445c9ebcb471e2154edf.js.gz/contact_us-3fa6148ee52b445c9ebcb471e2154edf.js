/**
 * Created by Charlie on 22/08/2016.
 */


$(function() {
    $('#contact_us_message').html('');
});
