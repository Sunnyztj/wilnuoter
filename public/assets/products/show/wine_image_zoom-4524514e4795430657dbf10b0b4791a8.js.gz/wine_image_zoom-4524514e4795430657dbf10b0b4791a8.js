/**
 * Created by Charlie on 30/08/2016.
 */


$(function() {
    $('#large-image').elevateZoom();
});
